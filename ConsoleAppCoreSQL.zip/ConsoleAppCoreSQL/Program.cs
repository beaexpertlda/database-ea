﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Data.SqlClient;

Console.WriteLine("Hello, SQL SERVER World!");

// CONNECT
// Encrypt=Strict;ServerCertificate=C:\\certificates\\server.cer
// Added support for TLS 1.3 for .NET Core and SNI Native. #1821
// Added ServerCertificate setting for Encrypt=Mandatory or Encrypt=Strict. #1822 Read
string connectionString = "Data Source=(local);Initial Catalog=Northwind;Integrated Security=SSPI;Encrypt=False";

using var connection = new SqlConnection(connectionString);
connection.Open();




connection.Close();
Console.WriteLine("Goodbye!!!");